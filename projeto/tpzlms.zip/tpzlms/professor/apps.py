from django.apps import AppConfig

class ProfessorConfig(AppConfig):
    name = 'professor'
