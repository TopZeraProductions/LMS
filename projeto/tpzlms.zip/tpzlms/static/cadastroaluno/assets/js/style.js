// $(function(){

// 	$("aside .logo").click(function(){
// 		if($("aside").hasClass('active')){
// 			$("aside").removeClass('active');
// 		}else{
// 			$("aside").addClass('active');			
// 		}
// 	});

// 	//Busca Curso - Cadastro Professor
// 	$('.div_disc').css('display', 'none');
// 	buscaCurso = function(){
// 		if($("#select_curso").val()=="si"){
// 			$('.div_disc').slideDown();
// 			var val = $("#select_curso").val();
// 			// console.log("Ok");	
// 		}else {
// 			$('.div_disc').slideUp();
// 		}
// 	}

// 	// $('.div_sem').css('display', 'none');	
// 	// buscaSemestre = function(){
// 	// 	if($("#select_semestre").val() == "si"){
// 	// 		$('.div_sem').slideDown();			
// 	// 	}else{
// 	// 		$('.div_sem').slideUp();
// 	// 	}
// 	// }


// 	// var val = $("#select_curso").val();
// 	// console.log(val);
// });

