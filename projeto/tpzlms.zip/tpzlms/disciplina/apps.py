from django.apps import AppConfig


class DisciplinaConfig(AppConfig):
    name = 'disciplina'
